import { createAction, props } from '@ngrx/store';

export const bookMaterial = createAction('[Material] Book material',
    props<{ materialId: number, amount: number }>());