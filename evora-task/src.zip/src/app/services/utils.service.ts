import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
})
export class UtilsService {

    constructor() { }

    // static getMaterialsLocalStorage() {
    //     return JSON.parse(localStorage.getItem("materials")!);
    // }
    // static saveMaterialsLocalStorage(json: any) {
    //     localStorage.setItem("materials", JSON.stringify(json));
    // }


}
