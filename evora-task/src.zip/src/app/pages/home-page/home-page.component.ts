import { Component } from '@angular/core';
import { Materials } from 'src/app/classes/materials';

@Component({
    selector: 'app-home-page',
    templateUrl: './home-page.component.html',
    styleUrls: ['./home-page.component.scss']
})
export class HomePageComponent {

    public ms: Materials;

    public filterInput;

    constructor() {
        this.ms = new Materials();

        console.log(this.ms);
        
    }

    ngOnInit() { }

    book(params: any) {
        let materialId = params.materialId;
        let amount = params.amount;

        this.ms.materials[materialId-1].Quantity += amount;
        this.ms.materials[materialId-1].Available -= amount;

        this.ms.saveMaterials();
    }
    

    getMaterialsFiltered() {
        return this.ms.materials.filter(e => { return (e.DescTxt).includes(this.filterInput || "") });
    }
}
