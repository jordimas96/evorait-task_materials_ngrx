import { createReducer, on } from '@ngrx/store';
import * as MaterialsActions from './materials.actions';
import { Materials } from './classes/materials';

export interface MaterialsState {
    materials: any[];
}

export const initialState: MaterialsState = {
    materials: [],
};

export const materialsReducer = createReducer(
    initialState,
    on(MaterialsActions.bookMaterial, (state, { materialId, amount }) => {
        // Create new obj material ???? why
        
        state.materials[materialId].Quantity += amount;
        state.materials[materialId].Available -= amount;
        return {
            ...state
        };
    }),
);
