import { Component, Input } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Material } from 'src/app/classes/material';
import { Materials } from 'src/app/classes/materials';


@Component({
    selector: 'app-material-details',
    templateUrl: './material-details.component.html',
    styleUrls: ['./material-details.component.scss']
})
export class MaterialDetailsComponent {

    public materials: Materials;
    public material: Material;

    inputQuantity;

    inputValueCorrect = true;


    constructor(private route: ActivatedRoute, private router: Router) {
        

        this.route.paramMap.subscribe(params => {
            const id = params.get('id');
            if (id) {
                this.materials = new Materials();
                this.material = this.materials.getMaterial(id);

            }
            if (!id || !this.material)
                alert("material  not found");
        });
        
    }

    book() {
        // Test input correct //
        this.inputValueCorrect = !isNaN(this.inputQuantity) && this.inputQuantity > 0;

        if (!this.inputValueCorrect) {
            alert("Input value incorrect");
            return;
        }
        let inputQuantityInt = Number.parseInt(this.inputQuantity);

        if (inputQuantityInt > this.material.Available) {
            alert("Not enough items available");
            return;
        }

        this.material.Quantity += inputQuantityInt;
        this.material.Available -= inputQuantityInt;


        // Re save to LocalStorage //
        this.materials.saveMaterials();
        
        
    }

    back() {
        let i = this.material.id - 1;
        if (i <= 0) i = this.materials.materials.length;
        this.router.navigate(["material-details/" + i]);
    }
    next() {
        let i = this.material.id + 1;
        if (i > this.materials.materials.length) i = 1;
        this.router.navigate(["material-details/" + i]);
    }


}
