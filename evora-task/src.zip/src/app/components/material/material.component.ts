import { bookMaterial } from './../../materials.actions';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Material } from '../../classes/material';
import { Store } from '@ngrx/store';

@Component({
    selector: 'app-material',
    templateUrl: './material.component.html',
    styleUrls: ['./material.component.scss']
})
export class MaterialComponent {
    @Input() material: Material;

    @Output() book = new EventEmitter<any>();

    @Output() save = new EventEmitter<void>();

    inputQuantity: number;

    inputValueCorrect = true;


    constructor(private store: Store<Material>) { }

    
    ngOnInit() { }

    clickBook() {

        if (this.inputQuantity > this.material.Available) {
            alert("Not enough items available");
            return;
        }

        // this.store.dispatch(bookMaterial({ materialId: this.material.id, amount: this.inputQuantity }));

        // this.material.book(inputQuantityInt);
        // this.material.Quantity += this.inputQuantity;
        // this.material.Available -= this.inputQuantity;

        // emit book event the parent will book and also save to localstorage //
        this.book.emit({ materialId: this.material.id, amount: this.inputQuantity });
    }
}
