import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomePageComponent } from './pages/home-page/home-page.component';
import { MaterialComponent } from './components/material/material.component';
import { FormsModule } from '@angular/forms';
import { MaterialDetailsComponent } from './components/material-details/material-details.component';
import { StoreModule } from '@ngrx/store';
import { materialsReducer } from './material.reducer';

@NgModule({
  declarations: [
    AppComponent,
    HomePageComponent,
    MaterialComponent,
    MaterialDetailsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    StoreModule.forRoot({ materials: materialsReducer }), 
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
