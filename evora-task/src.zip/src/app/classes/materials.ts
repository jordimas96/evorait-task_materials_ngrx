import { UtilsService } from './../services/utils.service';
import * as materialsFileContent from '../../assets/MatPricingSet.json';

export class Materials {

    public materials: any[];

    constructor() {

        let localStorageMaterials = this.getMaterials();


        // Take materials from local Storage //
        if (localStorageMaterials) {
            this.materials = localStorageMaterials;
        }
        // Or get materials from file //
        else {
            // Read from file //
            let materialsJson = materialsFileContent;
            this.materials = materialsJson.d.PartSet.results;
            

            // Artificially add ids for better management //
            this.materials.forEach((e, i) => { e.id = i + 1; });

            // Parse numbers to integer //
            this.materials.forEach(e => {
                e.Quantity = parseInt(e.Quantity);
                e.Available = parseInt(e.Available);
            });

            this.saveMaterials();
        }
        
    }


    public getMaterial(id) {
        let res = this.materials.filter((material) => { return material.id == id });
        return res[0] || null;
    }


    // LocalStorage //
    private getMaterials() {
        return JSON.parse(localStorage.getItem("materials")!);

        // this.store.select('materials').pipe(map(materialsState => materialsState.materials.find(material => material.id === id)));
    }
    public saveMaterials() {
        localStorage.setItem("materials", JSON.stringify(this.materials));


    }


    
}
