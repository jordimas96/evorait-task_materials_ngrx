import { Materials } from './materials';

describe('Materials', () => {
  it('should create an instance', () => {
    expect(new Materials()).toBeTruthy();
  });
});
